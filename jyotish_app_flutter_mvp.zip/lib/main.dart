import 'package:flutter/material.dart';

void main() {
  runApp(const JyotishApp());
}

class JyotishApp extends StatelessWidget {
  const JyotishApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Jyotish',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1020),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD4AF37),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF11152A),
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _index = 0;

  final pages = const [
    HomeTab(),
    KundaliPage(),
    PanchangPage(),
    LibraryPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Kundali'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Panchang'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Grantha'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 230,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            title: const Text('कालज्ञानं फलप्रदम्'),
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF171C38), Color(0xFF0D1020)],
                ),
              ),
              child: const Center(
                child: Icon(Icons.auto_awesome, size: 78, color: Color(0xFFD4AF37)),
              ),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              const Text(
                'ग्रहगणितमिति ज्योतिषम्',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                'ज्योतिषशास्त्र अध्ययन एवं परामर्श केन्द्र',
                style: TextStyle(color: Colors.white.withOpacity(.72)),
              ),
              const SizedBox(height: 20),
              const TrialCard(),
              const SizedBox(height: 18),
              const SectionTitle('मुख्य सेवाहरू'),
              const SizedBox(height: 10),
              const FeatureGrid(),
              const SizedBox(height: 20),
              const SectionTitle('ज्योतिष अध्ययन'),
              const SizedBox(height: 10),
              const LibraryPreview(),
            ]),
          ),
        ),
      ],
    );
  }
}

class TrialCard extends StatelessWidget {
  const TrialCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFF1A1F3A),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 28,
              backgroundColor: Color(0xFFD4AF37),
              child: Icon(Icons.card_giftcard, color: Colors.black),
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('२ वटा Free Trial', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  SizedBox(height: 4),
                  Text('Paid consultation/features का पहिलो २ प्रयोग निःशुल्क।'),
                ],
              ),
            ),
            TextButton(onPressed: () {}, child: const Text('हेर्नुहोस्')),
          ],
        ),
      ),
    );
  }
}

class FeatureGrid extends StatelessWidget {
  const FeatureGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('कुण्डली', Icons.auto_awesome, const KundaliPage()),
      ('पञ्चाङ्ग', Icons.calendar_month, const PanchangPage()),
      ('मुहूर्त', Icons.access_time, const PanchangPage()),
      ('परामर्श', Icons.chat, const ConsultationPage()),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.35,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item.$3)),
          child: Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(item.$2, size: 34, color: const Color(0xFFD4AF37)),
                  const SizedBox(height: 8),
                  Text(item.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) =>
      Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold));
}

class LibraryPreview extends StatelessWidget {
  const LibraryPreview({super.key});

  @override
  Widget build(BuildContext context) {
    final books = ['सामुद्रिकशास्त्रम्', 'मुहूर्तचिन्तामणिः', 'बृहत्जातकम्'];
    return Column(
      children: books.map((b) => Card(
        elevation: 0,
        child: ListTile(
          leading: const Icon(Icons.menu_book, color: Color(0xFFD4AF37)),
          title: Text(b),
          subtitle: const Text('निःशुल्क अध्ययन सामग्री'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LibraryPage(initialBook: b))),
        ),
      )).toList(),
    );
  }
}

class KundaliPage extends StatefulWidget {
  const KundaliPage({super.key});

  @override
  State<KundaliPage> createState() => _KundaliPageState();
}

class _KundaliPageState extends State<KundaliPage> {
  final date = TextEditingController();
  final time = TextEditingController();
  final place = TextEditingController();

  @override
  void dispose() {
    date.dispose(); time.dispose(); place.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('कुण्डली निर्माण')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Icon(Icons.auto_awesome, size: 64, color: Color(0xFFD4AF37)),
          const SizedBox(height: 12),
          const Text('जन्म विवरण', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 22),
          _field(date, 'जन्म मिति', Icons.date_range, 'DD/MM/YYYY'),
          _field(time, 'जन्म समय', Icons.access_time, 'HH:MM'),
          _field(place, 'जन्म स्थान', Icons.location_on, 'City, Country'),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () {
              if (date.text.isEmpty || time.text.isEmpty || place.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('कृपया सबै विवरण भर्नुहोस्।')));
                return;
              }
              Navigator.push(context, MaterialPageRoute(builder: (_) => KundaliResultPage(
                date: date.text, time: time.text, place: place.text,
              )));
            },
            icon: const Icon(Icons.calculate),
            label: const Padding(padding: EdgeInsets.all(12), child: Text('कुण्डली तयार गर्नुहोस्')),
          ),
          const SizedBox(height: 16),
          const Text('नोट: यो पहिलो UI prototype हो। वास्तविक ग्रह/लग्न गणनाका लागि ephemeris calculation engine जोड्नुपर्छ।',
            style: TextStyle(color: Colors.white60)),
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, String hint) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: c,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            prefixIcon: Icon(icon),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      );
}

class KundaliResultPage extends StatelessWidget {
  final String date, time, place;
  const KundaliResultPage({super.key, required this.date, required this.time, required this.place});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('जन्मपत्रिका')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: ListTile(
              title: Text('$date • $time'),
              subtitle: Text(place),
              leading: const Icon(Icons.person, color: Color(0xFFD4AF37)),
            ),
          ),
          const SizedBox(height: 18),
          Container(
            height: 300,
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFD4AF37), width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Text('कुण्डली Chart\n\n(Real calculation engine पछि जोडिनेछ)',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 20)),
            ),
          ),
          const SizedBox(height: 18),
          const InfoCard(title: 'लग्न', value: '—'),
          const InfoCard(title: 'चन्द्र राशि', value: '—'),
          const InfoCard(title: 'नक्षत्र', value: '—'),
          const InfoCard(title: 'दशा', value: '—'),
        ],
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final String title, value;
  const InfoCard({super.key, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    child: ListTile(title: Text(title), trailing: Text(value, style: const TextStyle(color: Color(0xFFD4AF37)))),
  );
}

class PanchangPage extends StatelessWidget {
  const PanchangPage({super.key});

  @override
  Widget build(BuildContext context) {
    final data = [
      ('तिथि', 'पञ्चमी'),
      ('वार', 'बुधवार'),
      ('नक्षत्र', '—'),
      ('योग', '—'),
      ('करण', '—'),
      ('सूर्योदय', '—'),
      ('सूर्यास्त', '—'),
      ('राहुकाल', '—'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('दैनिक पञ्चाङ्ग')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(child: ListTile(
            leading: Icon(Icons.today, color: Color(0xFFD4AF37)),
            title: Text('आजको पञ्चाङ्ग'),
            subtitle: Text('स्थानीय स्थान र वास्तविक गणना पछि जोडिनेछ'),
          )),
          ...data.map((x) => Card(
            elevation: 0,
            child: ListTile(title: Text(x.$1), trailing: Text(x.$2)),
          )),
        ],
      ),
    );
  }
}

class LibraryPage extends StatelessWidget {
  final String? initialBook;
  const LibraryPage({super.key, this.initialBook});

  @override
  Widget build(BuildContext context) {
    final books = [
      'सामुद्रिकशास्त्रम्',
      'मुहूर्तचिन्तामणिः',
      'बृहत्जातकम्',
      'फलित ज्योतिष परिचय',
      'ज्योतिषशास्त्र अध्ययन सामग्री',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('निःशुल्क ज्योतिष ग्रन्थालय')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Card(child: Padding(
            padding: EdgeInsets.all(16),
            child: Text('विद्यार्थी तथा सामान्य प्रयोगकर्ताका लागि उपलब्ध कानुनी/अनुमतिप्राप्त सामग्री यहाँ राख्न सकिन्छ।'),
          )),
          ...books.map((b) => Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.menu_book, color: Color(0xFFD4AF37)),
              title: Text(b),
              subtitle: const Text('Free'),
              onTap: () => _openBook(context, b),
            ),
          )),
        ],
      ),
    );
  }

  void _openBook(BuildContext context, String book) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => BookPage(title: book)));
  }
}

class BookPage extends StatelessWidget {
  final String title;
  const BookPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: const Padding(
      padding: EdgeInsets.all(18),
      child: SingleChildScrollView(
        child: Text(
          'यहाँ उक्त ग्रन्थको सार्वजनिक-domain वा उचित अनुमति प्राप्त सामग्री राखिनेछ।\n\n'
          'अध्याय १\n\n'
          'ग्रन्थको वास्तविक सामग्री backend/database बाट load गर्न सकिन्छ।',
          style: TextStyle(fontSize: 17, height: 1.7),
        ),
      ),
    ),
  );
}

class ConsultationPage extends StatelessWidget {
  const ConsultationPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ज्योतिषी परामर्श')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const CircleAvatar(radius: 48, child: Icon(Icons.person, size: 48)),
        const SizedBox(height: 12),
        const Text('शिवशंकर पौडेल', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Vedic Jyotish • Kundali • Muhurta', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        const TrialCard(),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.chat), label: const Text('Consultation सुरु गर्नुहोस्')),
      ],
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('मेरो Profile')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
        SizedBox(height: 14),
        Center(child: Text('Guest User', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        SizedBox(height: 24),
        Card(child: ListTile(leading: Icon(Icons.card_giftcard), title: Text('Free Trial'), subtitle: Text('२ मध्ये २ प्रयोग बाँकी'))),
        Card(child: ListTile(leading: Icon(Icons.history), title: Text('Kundali History'))),
        Card(child: ListTile(leading: Icon(Icons.settings), title: Text('Settings'))),
      ],
    ),
  );
}

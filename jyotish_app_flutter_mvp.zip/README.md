# Jyotish App — Flutter MVP

## Run
1. Install Flutter and Android Studio.
2. Create/open this project.
3. Run:
   flutter pub get
   flutter run

## Build APK
flutter build apk --release

APK:
build/app/outputs/flutter-apk/app-release.apk

## Current MVP
- Home dashboard
- Kundali input/result prototype
- Panchang prototype
- Free scripture library UI
- Consultation UI
- Profile UI
- Free-trial UI

## Next development
- Real Swiss Ephemeris-based calculations
- Location/geocoding
- Real Panchang calculations
- Authentication/database
- Server-side 2-use trial enforcement
- Secure payments/subscriptions
- Admin panel and content management
